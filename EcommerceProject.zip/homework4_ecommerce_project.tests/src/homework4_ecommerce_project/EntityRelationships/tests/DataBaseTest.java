/**
 */
package homework4_ecommerce_project.EntityRelationships.tests;

import homework4_ecommerce_project.EntityRelationships.DataBase;
import homework4_ecommerce_project.EntityRelationships.EntityRelationshipsFactory;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Data Base</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following operations are tested:
 * <ul>
 *   <li>{@link homework4_ecommerce_project.EntityRelationships.DataBase#NmEntities() <em>Nm Entities</em>}</li>
 * </ul>
 * </p>
 * @generated
 */
public class DataBaseTest extends NamedElementTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(DataBaseTest.class);
	}

	/**
	 * Constructs a new Data Base test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DataBaseTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Data Base test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected DataBase getFixture() {
		return (DataBase)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(EntityRelationshipsFactory.eINSTANCE.createDataBase());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

	/**
	 * Tests the '{@link homework4_ecommerce_project.EntityRelationships.DataBase#NmEntities() <em>Nm Entities</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see homework4_ecommerce_project.EntityRelationships.DataBase#NmEntities()
	 * @generated
	 */
	public void testNmEntities() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

} //DataBaseTest
