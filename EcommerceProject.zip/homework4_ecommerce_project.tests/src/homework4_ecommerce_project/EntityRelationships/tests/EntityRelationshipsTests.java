/**
 */
package homework4_ecommerce_project.EntityRelationships.tests;

import junit.framework.Test;
import junit.framework.TestSuite;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test suite for the '<em><b>EntityRelationships</b></em>' package.
 * <!-- end-user-doc -->
 * @generated
 */
public class EntityRelationshipsTests extends TestSuite {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(suite());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Test suite() {
		TestSuite suite = new EntityRelationshipsTests("EntityRelationships Tests");
		suite.addTestSuite(DataBaseTest.class);
		suite.addTestSuite(EntityTest.class);
		return suite;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EntityRelationshipsTests(String name) {
		super(name);
	}

} //EntityRelationshipsTests
