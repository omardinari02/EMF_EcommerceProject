/**
 */
package homework4_ecommerce_project.EntityRelationships.tests;

import junit.framework.Test;
import junit.framework.TestSuite;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test suite for the '<em><b>Ecommerce</b></em>' model.
 * <!-- end-user-doc -->
 * @generated
 */
public class EcommerceAllTests extends TestSuite {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(suite());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Test suite() {
		TestSuite suite = new EcommerceAllTests("Ecommerce Tests");
		suite.addTest(EntityRelationshipsTests.suite());
		return suite;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EcommerceAllTests(String name) {
		super(name);
	}

} //EcommerceAllTests
